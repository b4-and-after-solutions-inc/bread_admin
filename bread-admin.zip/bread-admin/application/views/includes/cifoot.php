</section><!-- container fluid -->

</div><!-- content wrapper -->

<footer class="main-footer">
	<div class="pull-right hidden-xs">Version 0.1.0</div>
	<strong>Copyright &copy; 2019 <a href="<?php echo base_url(); ?>">LTE</a> CI.</strong> All rights reserved.
</footer>

</div><!-- wrapper -->
</body>
</html>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
Class records_model extends CI_Model{

	function get_products(){
	  return $this->db->query("SELECT `id`, `name`, `description`, `pic`, `price`, `category`, `is_featured`, `active` FROM `products` WHERE 1 ORDER BY active desc")->result();
	}
	function get_featured_products(){
	  return $this->db->query("SELECT `id`, `name`, `description`, `pic`, `price`, `category`, `is_featured`, `active` FROM `products` WHERE is_featured = 1")->result();
	}
	function get_categories(){
	  return $this->db->query("SELECT `id`, `category`, `color_class` FROM `categories`")->result();
	}
	function get_product($id){
	  return $this->db->query("SELECT `id`, `name`, `description`, `pic`, `price`, `category`, `is_featured`, `active` FROM `products` WHERE id = ?", array($id))
	  			  ->row_array();
	}
	function get_total_products(){
		return $this->db->query("SELECT COUNT(`id`) as TOTAL FROM `products` WHERE 1")->row_array()['TOTAL'];
	}

	function get_catalog(){
	  	return array('products' => $this->get_products(), 'count' => $this->get_total_products(), 'featured'=> $this->get_featured_products());
	}

	function save_product($post){
		$act = $post['action'];
		unset($post['action']);
		switch ($act) {
			case 'add':
				unset($post['id']);
				$post['pic'] = $this->upload_file($_FILES['pic']);
				$this->db->insert('products', $post);
			break;
			case 'edit':
				if(!isset($_FILES['pic'])){
					unset($post['pic']);
				}
				else{
					$post['pic'] = $this->upload_file($_FILES['pic']);
				}
				$this->db->where('id', $post['id'])
						 ->update('products', $post);
			break;
		}
	}
	function upload_file(){
		$config = array(
		'upload_path' => "./uploads/products/",
		'allowed_types' => "jpg|png|jpeg",
		'overwrite' => TRUE,
		'max_size' => "10048000"
		);
		$this->load->library('upload', $config);
		if($this->upload->do_upload('pic')){
			$data = array('upload_data' => $this->upload->data());
			return $_FILES['pic']['name'];
		}
		else{
			$error = array('error' => $this->upload->display_errors());
			return 0;
		}
	}
	function create_filter($param){
		$filter = '';
		$filter .= $param['type'] != ''?" AND '".$param['type']."' LIKE concat('%', material_type, '%')":'';
	  	$filter .= $param['tag'] != ''?" AND (tags REGEXP '".$param['tag']."' AND tags != '')":'';
	  	$filter .= $param['last_id'] != 0?" AND id > ".$param['last_id']:'';
	  	return $filter; 
	}
	function get_materials($post){
	  	$filter = $this->create_filter($post);
	  	$materials = $this->db->query("SELECT `id`, `title`, `description`, `cover`, `aq_mode`, `supplier`, `date_acquired`, `price`, `material_type`, `tags` 
	  								FROM `material` WHERE 1 $filter LIMIT 50")
	  								->result();
	  foreach ($materials as $m) {
	  		$q = $this->db->query("SELECT * FROM `tags` WHERE ? LIKE CONCAT('%', tag_code, '%')", array($m->tags));
	  		$m->tags = $q->result();
	  }
	  return array('materials' => $materials, 'total_count' => $this->get_total_materials($filter));
	}

	function get_total_materials($filter){
		return $this->db->query("SELECT COUNT(`id`) as TOTAL FROM `material` WHERE 1 $filter LIMIT 10")->row_array()['TOTAL'];
	}
	function get_material_types(){
	  return $this->db->query("SELECT `id`, `material_type`, `icon` FROM `material_type` WHERE 1")->result();
	}

	function get_material($id){
	  	$m = $this->db->query("SELECT `id`, `title`, `description`, `cover`, `aq_mode`, `supplier`, `date_acquired`, `price`, `material_type`, `tags` 
	  								FROM `material` WHERE ID = ?", array($id))
	  								->row_array();
	  	$q = $this->db->query("SELECT * FROM `tags` WHERE ? LIKE CONCAT('%', tag_code, '%')", array($m['tags']));
	  	$m['tags'] = $q->result();
	  return $m;
	}


}
?>

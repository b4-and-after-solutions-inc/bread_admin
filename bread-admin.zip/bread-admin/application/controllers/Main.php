<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller
{

  public function index(){
  $cihead['Menu1'] = 'Dashboard';
  $cihead['category'] = $this->records_model->get_categories();
	$this->load->view('includes/cihead', $cihead);
	$this->load->view('table');
	$this->load->view('includes/cifoot');
  }

  function get_products(){
  	$this->output
  	    ->set_content_type("application/json")
  	    ->set_output(json_encode($this->records_model->get_catalog()));
  }
  function get_product(){
    $this->output
        ->set_content_type("application/json")
        ->set_output(json_encode($this->records_model->get_product($this->input->post('id'))));
  }
  function get_categories(){
    $this->output
        ->set_content_type("application/json")
        ->set_output(json_encode($this->records_model->get_categories()));
  }
  function save_product(){
      $this->records_model->save_product($this->input->post());
  }
}
